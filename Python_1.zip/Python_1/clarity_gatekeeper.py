import nltk
from nltk.corpus import stopwords
from textblob import TextBlob  # Import for sentiment analysis (optional)

# Download necessary NLTK resources (run once)
nltk.download('punkt')
nltk.download('stopwords')

# Negative keyword list
negative_keywords = ["hello", "thanks", "regards", "urgent"]  # Add more as needed


# Function to analyze email text
def analyze_email(text):
    # Preprocess text
    text = text.lower()  # Convert to lowercase
    tokens = nltk.word_tokenize(text)  # Tokenize words
    filtered_tokens = [word for word in tokens if
                       word not in stopwords.words('english') and word not in negative_keywords]

    # Score calculation
    score = 0
    if len(text.split()) > 10:  # Check for sentence complexity
        score += 2
    for word in filtered_tokens:
        if any(char.isalpha() for char in word):  # Check for alphabetic words (exclude punctuation)
            if word in ["why", "how", "what"]:  # Question words
                score += 3
            # Add logic for named entity recognition (using libraries like spaCy)

    # Optional: Sentiment analysis
    sentiment = TextBlob(text).sentiment.polarity  # Positive sentiment score (higher indicates stronger sentiment)
    if sentiment > 0.2:
        score += 0.5  # Add a point for positive sentiment (adjust value as needed)

    return score

# ... rest of the script remains the same (refer to previous response for sending response email)
