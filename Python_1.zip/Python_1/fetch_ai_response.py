import requests

url = 'https://app.gradient.ai/api/models/complete'
headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',
    'Cookie': '_gcl_au=1.1.1671889110.1715869327; _ga=GA1.1.1269319972.1715869328; cb_user_id=null; cb_group_id=null; cb_anonymous_id=%2271ca702b-3750-4ead-b42b-e20891dd2714%22; ory_kratos_session=MTcxNTkzODA5M3x0WVVKeS1zQkc3eGx3VnczUnByS21EeS0tQWJyTWpvc1dnTmtReTgxMmpwd0pudEdkVGFWYjJwQjhhTVJyYmc0bm0tTWNWZnljTVROSnBaVmg2eHV0ak9ScGlnZ2FwTTNzSzdjVWRDTVFuczdFc1VhZm9kSWNNcmxpalV1V3hQQzBqRjBMay14N3VjdEhVdmsxVWE3NmpZcExyM3B3VjFPZ2stc3BIZGZSNHdvbVhScFgwelBQMUp4enQ2TDlaazFvZDkydU55WGI0bU9DYlpIdk1LNWJyQ0VDaWg4czY3RHdXTFpkNVcyVGxIZWU0WENpaXZIb3VqTTRjTjlVc21Lb1FzeGdsemN4LVlifMqxuxcAJZmnl4LAQFO1aoeO8ZcswgRZMCKODauonmZC; _ga_JGQNQSNJTH=GS1.1.1716002487.4.0.1716002487.0.0.0',
    'Origin': 'https://app.gradient.ai',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'x-gradient-browser-client': '1',
    'x-gradient-workspace-id': '2891a605-95ba-4714-834a-3185d5c06aca_workspace'
}


def fetchAIResponse(query):
    data = {
        "autoTemplate": True,
        "maxGeneratedTokenCount": None,
        "query": query,
        "rag": {
            "collectionId": "65aa5f93-cba4-4877-9a62-e64ba6113c0f_rag_config"
        },
        "temperature": None,
        "topK": None,
        "topP": None
    }
    response = requests.post(url + '?id=07396fc3-64f1-43e7-b194-f10843e741f0_base_ml_model', headers=headers, json=data)
    print(response)
    print("rrresponse")
    return response.json()


if __name__ == "__main__":
    query = "### Problem Statement Using the example given above as reference, generate an appropriate response for the following problem statement. “Logs: Device block operation failed for device ID: 1234522, what should be done?” Alert if any crucial information is missing in the problem statement to trigger the required API."
    response_data = fetchAIResponse(query)
    print(response_data)
