import speech_recognition as sr
from flask import Flask, request, jsonify
from flask_cors import CORS
from pydub import AudioSegment
from textblob import TextBlob

import AdvanceParamGatekeeper as apg

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes


# Function to recognize speech from audio file
def recognize_speech(audio_file_path):
    recognizer = sr.Recognizer()
    audio_file = sr.AudioFile(audio_file_path)

    with audio_file as source:
        audio = recognizer.record(source)

    try:
        text = recognizer.recognize_google(audio)
        print("You said:", text)
        return text
    except sr.UnknownValueError:
        print("Sorry, I couldn't understand what you said.")
        return ""
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
        return ""


# Function to analyze sentiment
def analyze_sentiment(text):
    if text:
        blob = TextBlob(text)
        sentiment_score = blob.sentiment.polarity
        if sentiment_score > 0:
            return "Positive"
        elif sentiment_score == 0:
            return "Neutral"
        else:
            return "Negative"
    else:
        return "No text to analyze"


# Function to detect pitch
def detect_pitch(audio_file_path):
    sound = AudioSegment.from_file(audio_file_path)
    pitch = sound.dBFS
    return pitch


@app.route("/process_audio", methods=["POST"])
def process_audio():
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400

    audio_file = request.files['audio']
    audio_file_path = "temp.wav"

    # Save audio file to a temporary location
    audio_file.save(audio_file_path)

    # Convert audio file to PCM WAV format
    sound = AudioSegment.from_file(audio_file_path)
    sound.export(audio_file_path, format="wav")

    # Recognize speech
    text = recognize_speech(audio_file_path)
    sentiment = analyze_sentiment(text)
    pitch = detect_pitch(audio_file_path)

    sentiments_hurted = apg.score_query(text)
    sentiments_hurted["sentimental"] = sentiment
    sentiments_hurted["pitching"] = pitch
    sentiments_hurted["texttext"] = text
    # Clean up the temporary audio file
    # os.remove(audio_file_path)
    print("sdfhjkfhsdkjfh")
    print(sentiments_hurted)
    return jsonify(sentiments_hurted)


if __name__ == "__main__":
    app.run(debug=True, port=5001)
