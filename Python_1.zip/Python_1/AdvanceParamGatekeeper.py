import nltk
from flask import Flask, request, jsonify
from flask_cors import CORS
from nltk.sentiment.vader import SentimentIntensityAnalyzer

import fetch_ai_response

nltk.download('vader_lexicon')  # Download sentiment lexicon (one-time)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes


def score_query(query):
    """
    This function scores a query string on various parameters using sentiment lexicon.

    Args:
        query: The string to be scored.

    Returns:
        A dictionary containing the scores for each parameter.
    """
    scores = {}

    # Sentiment analysis using VADER lexicon
    analyzer = SentimentIntensityAnalyzer()
    sentiment = analyzer.polarity_scores(query)
    scores["Sentiment"] = sentiment["compound"]

    # Emotion detection based on sentiment scores
    emotions = []
    if sentiment["neg"] > 0.5:
        emotions.append("Frustration")
    if sentiment["pos"] == 0 and sentiment["neg"] > 0:
        emotions.append("Sadness")
    scores["Emotion"] = emotions if emotions else "Neutral"

    # Valid query check (can be further improved)
    scores["Valid Query"] = len(query.split()) > 3  # Simple check for query length

    # Urgency analysis based on sentiment intensity
    urgency_threshold = 0.7
    scores["Urgency"] = "high" if sentiment["neg"] > urgency_threshold else "Medium"

    # Politeness analysis based on presence of politeness words
    politeness_words = ["please", "thank you"]
    politeness_score = sum(word in query.lower() for word in politeness_words)
    scores["Politeness"] = politeness_score

    # Specificity analysis based on keywords
    specificity_words = ["date", "deadline"]
    specificity_score = "Medium"
    for word in specificity_words:
        if word in query.lower():
            specificity_score = "High"
            break
    scores["Specificity"] = specificity_score

    # Completeness analysis (assuming some context is available)
    scores["Completeness"] = "Medium"  # Can be adjusted based on context

    # Actionability analysis based on verbs
    action_verbs = ["request", "need"]
    actionability_score = sum(word in query.lower() for word in action_verbs)
    scores["Actionable"] = actionability_score

    if scores["Valid Query"]:
        print("valid")
        ai_response = fetch_ai_response.fetchAIResponse(query)  # Call the function to fetch AI response
        print("ai_response")
        print(ai_response)
        scores["AI_Response"] = ai_response  # Include AI response in the scores

    return scores


@app.route('/score_query', methods=['POST'])
def score_query_api():
    data = request.get_json()
    query = data.get('query')
    if query:
        scores = score_query(query)
        print(scores)
        # If Valid Query is true, call fetchAIResponse and include its response in the final API response

        return jsonify(scores)
    else:
        return jsonify({'error': 'No query provided'})


if __name__ == '__main__':
    app.run(debug=True)
