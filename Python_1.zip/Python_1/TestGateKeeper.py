# Assuming you have the script saved as clarity_gatekeeper.py

from clarity_gatekeeper import analyze_email  # Import the function

inputs = [
    "Hello, I hope this email finds you well. I'm experiencing issues with accessing the company's VPN. Can you please assist me in resolving this matter?",
    "Hi, I'm having trouble understanding the new software update. Could you provide some guidance on how to navigate the changes?",
    "I'm encountering errors when trying to submit my expense report. It seems there might be an issue with the system. Can you look into this and provide assistance?",
    "Why hasn't the server maintenance been scheduled yet? It's crucial to address this to avoid potential disruptions to our operations.",
    "What steps are needed to finalize the budget for the upcoming quarter? I'd appreciate some clarity on the timeline and required inputs.",
    "I'm concerned about the delay in receiving feedback on the proposal. Can you provide an update on the review process?",
    "Thanks for your assistance in resolving the technical issue with my laptop. I'm grateful for your prompt response and support.",
    "I'm struggling to meet the deadline for the project deliverables due to unforeseen challenges. Can we discuss potential solutions to ensure timely completion?",
    "I need clarification on the requirements for the upcoming client presentation. Can you outline the key points that need to be covered?",
    "I haven't received a response to my request for additional resources for the project. Could you please confirm if the request has been received and processed?",
    "Thank you for your attention to this matter. I'm looking forward to your guidance on how to proceed with resolving the issue.",
    "I appreciate your prompt response to my inquiry. Could you provide further details on the proposed solution for the customer's issue?",
    "I'm experiencing difficulties accessing the shared drive. Can you investigate and address this issue as soon as possible?",
    "Could you please advise on the appropriate course of action for handling the client's complaint?",
    "I'm encountering technical issues with the software application. Can you escalate this matter to the IT team for assistance?",
    "What are the next steps for onboarding the new team member? I want to ensure a smooth transition and integration into the team.",
    "I'm unable to access my email account. Can you help troubleshoot the issue and restore access?",
    "What measures are being taken to address the security breach detected in the system?",
    "I need assistance in setting up the video conferencing software for the team meeting tomorrow. Can you provide guidance on the setup process?",
    "I'm concerned about the quality of the latest product batch. Can you investigate and address any potential issues with the manufacturing process?",
    "How can I update my contact information in the company directory?",
    "I'm experiencing performance issues with the company's website. Can you look into this and optimize the site for better responsiveness?",
    "What is the protocol for reporting workplace safety incidents? I need guidance on how to proceed with documenting an incident.",
    "I'm having difficulty accessing the training materials for the new employee orientation. Can you provide assistance in accessing the resources?",
    "I need clarification on the new company policy regarding remote work. Can you explain the key changes and implications for employees?",
    "I'm encountering errors when trying to submit my timesheet. Can you assist me in resolving this issue?",
    "Why was the deadline for the project extended without prior notice? I'd appreciate some transparency regarding the decision-making process.",
    "What are the requirements for obtaining approval for travel expenses? I need guidance on how to prepare and submit the expense report.",
    "I'm experiencing issues with the software application freezing unexpectedly. Can you provide troubleshooting steps to resolve this issue?",
    "I'm unable to access the training portal for completing the mandatory compliance training. Can you investigate and provide assistance?",
    "How can I access the recorded sessions from the recent training workshop? I want to review the content covered during the sessions.",
    "I'm encountering difficulties in coordinating schedules for the project team members. Can you provide assistance in scheduling a meeting to discuss this?",
    "What steps should I take to address a conflict with a colleague? I need guidance on how to approach the situation professionally.",
    "I'm experiencing problems with my company-issued mobile device. Can you provide troubleshooting steps to resolve the issues?",
    "I'm concerned about the accuracy of the financial reports. Can you conduct a review to ensure data integrity and reliability?",
    "How can I request access to additional software applications required for my role? I need assistance in obtaining the necessary permissions.",
    "I'm unable to access the company intranet. Can you investigate and address the issue to restore access?",
    "What are the expectations for employee performance evaluations? I'd like clarification on the criteria and process for conducting the evaluations.",
    "I'm having difficulty connecting to the company's Wi-Fi network. Can you provide troubleshooting steps to resolve the connectivity issues?",
    "I'm experiencing delays in receiving responses to my emails. Can you advise on strategies for improving communication efficiency?",
    "How can I update my training certifications in the employee records system? I need assistance in documenting my qualifications.",
    "I'm encountering challenges in navigating the new project management software. Can you provide guidance on how to use the tools effectively?",
    "What resources are available for employees seeking professional development opportunities? I'd like to explore options for enhancing my skills.",
    "I'm experiencing issues with accessing the company's online collaboration platform. Can you assist in troubleshooting the login problems?",
    "How can I request technical support for setting up the audiovisual equipment for the upcoming presentation? I need assistance in ensuring smooth operation during the event.",
    "I'm concerned about the sustainability practices of our suppliers. Can you provide information on how we evaluate and monitor supplier compliance?",
    "What are the guidelines for requesting budget approval for departmental expenses? I need clarification on the process for submitting budget proposals.",
    "I'm experiencing difficulties in accessing the project files stored on the shared drive. Can you investigate and address any permissions issues?",
    "How can I access the latest version of the employee handbook? I need to review the updated policies and procedures.",
    "I'm encountering issues with printing documents from the office printer. Can you provide troubleshooting steps to resolve the printing problems?",
    "What measures are being taken to address the environmental impact of our business operations? I'd like to understand our sustainability initiatives.",
    "I'm having trouble logging into the company's online training platform. Can you assist me in resetting my password?",
    "How can I request approval for hiring additional staff for my department? I need guidance on preparing the staffing proposal.",
    "I'm experiencing difficulties in accessing the company's shared calendar. Can you investigate and address any synchronization issues?",
    "What are the protocols for reporting security incidents in the workplace? I need guidance on how to document and escalate security breaches.",
    "I'm encountering challenges in accessing the financial reports from the accounting system. Can you assist in troubleshooting the access issues?",
    "How can I request approval for purchasing new equipment for my team? I need assistance in preparing the equipment requisition form.",
    "I'm unable to access the online training modules for the compliance certification. Can you investigate and provide assistance in accessing the materials?",
    "What are the expectations for employee attendance at company events? I'd like clarification on the policy for participation in company-sponsored activities.",
]

# Calculate scores for each input
scores = [(text, analyze_email(text)) for text in inputs]
scores.sort(key=lambda x: x[1])

# Print scores
for text, score in scores:
    print(f"Email: {text}\nScore: {score}\n")
